package com.ecom.product.dto;

import com.ecom.product.entity.SubscribedProduct;

public class SubscribedProductDTO {
	
	int prodId;
	int buyerId;
	int quantity;
	
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public int getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	@Override
	public String toString() {
		return "SubscribedProductDTO [prodId=" + prodId + ", buyerId=" + buyerId + ", quantity=" + quantity + "]";
	}
	
	public static SubscribedProductDTO valueOf(SubscribedProduct subprod) {
		SubscribedProductDTO subprodDTO = new SubscribedProductDTO();
		subprodDTO.setProdId(subprod.getProdId());
		subprodDTO.setBuyerId(subprod.getBuyerId());
		subprodDTO.setQuantity(subprod.getQuantity());
						
		return subprodDTO;
	}
	
}
