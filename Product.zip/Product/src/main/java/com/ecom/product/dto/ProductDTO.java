package com.ecom.product.dto;

import com.ecom.product.entity.Product;

public class ProductDTO {

	int prodId;
	String productName;
	int price;
	int stock;
	String description;
	String image;
	int sellerId;
	String category;
	String subcategory;
	int productrating;
	
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSubcategory() {
		return subcategory;
	}
	public void setSubcategory(String subcategory) {
		this.subcategory = subcategory;
	}
	public int getProductrating() {
		return productrating;
	}
	public void setProductrating(int productrating) {
		this.productrating = productrating;
	}
	@Override
	public String toString() {
		return "ProductDTO [prodId=" + prodId + ", productName=" + productName + ", price=" + price + ", stock=" + stock
				+ ", description=" + description + ", image=" + image + ", sellerId=" + sellerId + ", category="
				+ category + ", subcategory=" + subcategory + ", productrating=" + productrating + "]";
	}
	
	// Converts Entity into DTO
	public static ProductDTO valueOf(Product prod) {
		ProductDTO prodDTO = new ProductDTO();
		prodDTO.setProdId(prod.getProdId());
		prodDTO.setProductName(prod.getProductName());
		prodDTO.setPrice(prod.getPrice());
		prodDTO.setStock(prod.getStock());
		prodDTO.setDescription(prod.getDescription());
		prodDTO.setImage(prod.getImage());
		prodDTO.setSellerId(prod.getSellerId());
		prodDTO.setCategory(prod.getCategory());
		prodDTO.setSubcategory(prod.getSubcategory());
		prodDTO.setProductrating(prod.getProductrating());
						
		return prodDTO;
	}
	
	// Converts DTO into Entity
	public Product createEntity() {
		Product prod = new Product();
		prod.setProdId(this.getProdId());
		prod.setProductName(this.getProductName());
		prod.setPrice(this.getPrice());
		prod.setStock(this.getStock());
		prod.setDescription(this.getDescription());
		prod.setImage(this.getImage());
		prod.setSellerId(this.getSellerId());
		prod.setCategory(this.getCategory());
		prod.setSubcategory(this.getSubcategory());
		prod.setProductrating(this.getProductrating());
		return prod;
	}

}
