package com.ecom.product.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import com.ecom.product.dto.ProductDTO;
import com.ecom.product.entity.Product;
import com.ecom.product.repository.ProductRepository;

@Service
public class ProductService {

	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ProductRepository productRepo;

	
	// Fetches all product details
	public List<ProductDTO> getAllProducts() {

		List<Product> products = productRepo.findAll();
		List<ProductDTO> productDTOs = new ArrayList<ProductDTO>();

		for (Product product : products) {
			ProductDTO productDTO = ProductDTO.valueOf(product);
			productDTOs.add(productDTO);
		}

			logger.info("Product details : {}", productDTOs);
			return productDTOs;
		}
		
	// Fetches product details by category
	public List<ProductDTO> getProductBycategory(@PathVariable String category) {

		List<Product> products = productRepo.findBycategory(category);
		List<ProductDTO> productDTOs = new ArrayList<ProductDTO>();

		for (Product product : products) {
			ProductDTO productDTO = ProductDTO.valueOf(product);
			productDTOs.add(productDTO);
		}
		
		logger.info("Product details by category : {}", productDTOs);

		return productDTOs;
	}
	
	// Fetches  product details by name 
	public List<ProductDTO> getProductByName(@PathVariable String productName) {

		List<Product> products = productRepo.findByproductname(productName);
		List<ProductDTO> productDTOs = new ArrayList<ProductDTO>();

		for (Product product : products) {
			ProductDTO productDTO = ProductDTO.valueOf(product);
			productDTOs.add(productDTO);
		}
		
		logger.info("Product details by name : {}", productDTOs);

		return productDTOs;
	}


}
