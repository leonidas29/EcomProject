package com.ecom.product.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ecom.product.dto.ProductDTO;
import com.ecom.product.service.ProductService;

@RestController
@CrossOrigin
public class ProductController {

	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ProductService prodService;
	
	//Fetches all product details
	@GetMapping(value="/api/product", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProductDTO> getAllProducts() {

		logger.info("Fetching product details");

		return prodService.getAllProducts();
	}
		
	//Fetches product details by name
	@GetMapping(value="/api/product/{productName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProductDTO> getProductByName(@PathVariable String productName) {

		logger.info("Fetching product details by name {}", productName);

		return prodService.getProductByName(productName);
	}
	
	//Fetches product details by category
	@GetMapping(value="/api/product/{category}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProductDTO> getProductBycategory(@PathVariable String category) {

		logger.info("Fetching product details by category {}",category);

		return prodService.getProductBycategory(category);
	}


}
